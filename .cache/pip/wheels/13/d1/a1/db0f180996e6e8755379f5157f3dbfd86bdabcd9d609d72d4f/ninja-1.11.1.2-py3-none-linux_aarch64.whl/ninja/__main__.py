from __future__ import annotations

from ninja import ninja

if __name__ == '__main__':
    ninja()
